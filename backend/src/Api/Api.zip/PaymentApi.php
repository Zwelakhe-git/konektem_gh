<?php
namespace Konektem\Api;

use Konektem\Utils\Log;
use Konektem\Models\UserModel;
use Konektem\Models\AdminModel;

Log::init();
class PaymentApi extends ApiParent{
    public function getPaymentInformation($req, $res){
        try{
            $pid = $req->params->id;
            $result = (new \Thunderpc\Vkurse\Models\AdminModel())->getSubscriptionPlanById($pid);
            return $res->status(200)->json([
                'success' => true,
                'plan' => $result
            ]);
        } catch(\Exception $e){
            Log::error("error getting payment info: {$e->getMessage()} at {$e->getFile()} line {$e->getLine()}");
            return $res->status(503)->json([
                'success' => false,
                'message' => 'Server error'
            ]);
        } catch(\Throwable $e){
            Log::error("error getting payment info: {$e->getMessage()} at {$e->getFile()} line {$e->getLine()}");
            return $res->status(503)->json([
                'success' => false,
                'message' => 'Server error'
            ]);
        }
    }

    public function processPayment($req, $res){
        try {
            // response format
            /**
             * {
                "plan_id": "author",
                "payment_method": "card",
                "save_card": true,
                "card_details": {
                    "number": "4242424242424242",
                    "exp_month": "12",
                    "exp_year": "28",
                    "cvc": "123",
                    "holder_name": "IVAN IVANOV"
                }
                }

                {
                "success": true,
                "redirect_url": "https://payment.example.com/confirm"
                }
             */
            Log::info("processing payment");
            $userModel = new UserModel();
            $adminModel = new AdminModel();
            $plan = $adminModel->getSubscriptionPlanById($req->body->plan_id);

            if(empty($plan)){
                return $res->status(503)->json([
                    'success' => false,
                    'message' => "plan {$req->body->plan_id} not found"
                ]);
            }
            
            $subId = $req->body->subscription_id;
            $subInfo = $adminModel->getSubscriptionById($subId);

            if(empty($subInfo)){
                return $res->status(503)->json([
                    'success' => false,
                    'message' => "Subscription $subId not created"
                ]);
            }

            $userId = $subInfo['user_id'];
            if($userModel->subscriptionPaid($subId, $userId)){
                Log::info("restricting double payment on subscription");
                return $res->status(200)->json([
                    'success' => true,
                    'redirect_url' => "/vkurse/user/me"
                ]);
            }

            Log::info("making payment on $subId for user $userId for plan {$req->body->plan_id}");
            $payRes = $userModel->makePayment($userId, $subId, 'succeeded', $plan['price'], 'stripe');
            if(!$adminModel->changeSubscriptionStatus($subId, 'active')){
                Log::warn("subscription $sid status failed to change");
            }
            if($payRes){
                return $res->status(200)->json([
                    'success' => true,
                    'redirect_url' => "/vkurse/user/me"
                ]);
            }
            return $res->status(503)->json([
                'success' => false,
                'message' => 'Failed to make payment'
            ]);
        } catch(\Exception $e){
            Log::error("error processing payment: {$e->getMessage()}");
            return $res->status(503)->json([
                'success' => false,
                'message' => 'Server error'
            ]);
        } catch(\Throwable $e){
            Log::error("error processing payment: {$e->getMessage()}");
            return $res->status(503)->json([
                'success' => false,
                'message' => 'Server error'
            ]);
        }
    }

    public function confirmPayment($req, $res){
        try {
            return $res->status(200)->json(json_decode('{
            "success": true,
            "subscription": {
                "id": "sub_123",
                "status": "active"
            }
        }', true));
        } catch(\Exception $e){
            Log::error("error confirming payment: {$e->getMessage()}");
            return $res->status(501)->json([
                'success' => false,
                'message' => 'Server error'
            ]);
        } catch(\Throwable $e){
            Log::error("error confirming payment: {$e->getMessage()}");
            return $res->status(501)->json([
                'success' => false,
                'message' => 'Server error'
            ]);
        }
    }

    public function createSubscription($req, $res){
        try {
            $payload = $this->getAuthTokenPayload();
            if(empty($payload)){
                Log::warn("creating subscription without user info");
                // return $res->status(503)->json([
                //     'success' => false,
                //     'message' => 'Authorization header not set'
                // ]);
            }
            $userId = $payload['userId'] ?? 3;
            $adminModel = new AdminModel();
            $userModel = new UserModel();
            
            $plan = $adminModel->getSubscriptionPlanById($req->body->plan_id);
            if(empty($plan)){
                return $res->status(503)->json([
                    'success' => false,
                    'message' => 'Invalid subscription plan'
                ]);
            }
            $pdo = $adminModel->pdo;
            $subId = \Thunderpc\Vkurse\Utils\SlugGenerator::makeUnique('sub_new', function($prefix) use ($pdo) {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM subscriptions WHERE subscription_id = ?");
                $stmt->execute([$prefix]);
                return $stmt->fetchColumn() > 0;
            });
            $paymentMethod = $req->body->payment_method ?? null;
            $result = $userModel->openSubscription($plan['period'], $userId, $subId, $paymentMethod);
            if(empty($result)){
                Log::warn("failed to open subscription for user $userId");
                return $res->status(503)->json([
                    'success' => false,
                    'message' => "Failed to created subscription"
                ]);
            }
            if($plan['is_free']){
                return $res->status(200)->json([
                    'success' => true,
                    'subscription' => [
                        'id' => $subId,
                        'plan_id' => $plan['id'],
                        'plan_name' => $plan['name'],
                        'started_at' => $result['started_at'],
                        'expires_at' => $result['expires_at']
                    ]
                ]);
            }
            $sid = $result['subscription_id'];
            return $res->status(200)->json([
                'success' => true,
                'redirect_url' => "/vkurse/payment?plan={$plan['id']}&sid=$sid",
                'message' => "Перенаправление на страницу оплаты"
            ]);
        } catch(\Exception $e){
            Log::error("error creating subscription");
            return $res->status(503)->json([
                'success' => false,
                'message' => 'Server error'
            ]);
        } catch(\Throwable $e){
            Log::error("error creating subscription");
            return $res->status(503)->json([
                'success' => false,
                'message' => 'Server error'
            ]);
        }
    }
}
?>